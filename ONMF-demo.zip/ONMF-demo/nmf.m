function [W, H] = nmf(V, K, MAXITER)
%Euclidean distance
 F = size(V,1);
 T = size(V,2);

  
rand('seed',0)

W = 1+rand(F, K);

H = 1+rand(K, F);
  %     J1=0;
%     J2=0;
%     J3=0;
%     J4=0;
% %    L2 = L1;
%     for t1 = 1:T
%         Wt = W(:,:,t);
%         Ht = H(:,:,t);
%         Vt = test(:,:,t);
%         Pt = P1(:,:,t);
%         
%         J1 = J1+norm(Pt.*(Vt-Wt*Ht),'fro') ;
%         if t1~=1        
%             J2 = J2+la1*(norm(Wt-W(:,:,t-1)*A,'fro')+norm(Ht-H(:,:,t-1)*B,'fro'));
%         end
%         J4 = J4 + la3*(norm(Wt,'fro')+norm(Ht,'fro'));
%     end
% 
%     J3 = la2*(norm(Wh1-Wt*A,'fro')+norm(Hh1-Ht*B,'fro'))+la3*(norm(A,'fro')+norm(B,'fro'));
% 
%     L1 = J1+J2+J3+J4;

  
for i=1:MAXITER
%     H = H .* (W'*(P.*V))./(W'*(P.*(W*H))+eps) ;%NMF with miss data
%     W = W .* (P.*V*H')./((P.*(W*H))*H'+eps);
    H = H .* (W'*(V))./(W'*((W*H))+eps) ;%NMF 
    W = W .* (V*H')./(((W*H))*H'+eps);%

%     W = W.*((V'*W*H+V*W*H')./((W*H*W')*(W*H'+W*H)+eps));%tri-NMF 
%     H = H.*((W'*V*W)./(W'*(W*H*W')*W+eps));

    
%     a = norm((V-(W*H)),'fro')/norm((V),'fro');
%         if a<0.01
%             
%             break
%         end
end
a=1;