function L = getLoss2(W,H,Wh1,Hh1,V,P,A,B,T,la1,la2)
    J1=0;
    J2=0;
    J3=0;
    J4=0;

    for t = 1:T
        Wt = W(:,:,t);
        Ht = H(:,:,t);

        At = A(:,:,t);
        Bt = B(:,:,t);
        Vt = V(:,:,t);
        if size(P,3)==1
            Pt = P;
        else
            Pt = P(:,:,t);
        end
        
        J1 = J1+norm(Pt.*(Vt-Wt*Ht),'fro').^2 ;
        if t~=1        
            J2 = J2+la1*(norm(Wt-W(:,:,t-1)*A(:,:,t-1),'fro').^2+norm(Ht-H(:,:,t-1)*B(:,:,t-1),'fro').^2);
        end
        %J3 = J3 + la2*(norm(Wh1-Wt*At,'fro')+norm(Hh1-Ht*Bt,'fro'));
        
        
    end
    J3 = la2.*(norm(Wh1-W(:,:,T)*At,'fro').^2+norm(Hh1-H(:,:,T)*Bt,'fro').^2);
    

    L = 0.5*(J1+J2+J3+J4);
