function gt_ba = ONMFMR(pre,T,k,la1,la2,Avg,in,inT)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% pre: the time span to predict
% T: window size
% k: dimention
% la1,la2,la3: lambda1,2,3
% Avg: Average historical data
% in: the data of prediction and groudtruth
% inT: during time,95%confidence


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rand('seed',0);
%%% a trick for journal version
if nargin > 7
    
    if pre>64
        for u = pre-T-2:size(Avg,3)
            U1 = Avg(:,:,u)';
            Avg(:,:,u)=U1;
            U2 = in(:,:,u)';
            in(:,:,u) = U2;
            U3 = inT(:,:,u)';
            inT(:,:,u) = U3; 
        end

    end
else
    if pre>64
        for u = pre-T-2:size(Avg,3)
            U1 = Avg(:,:,u)';
            Avg(:,:,u)=U1;
            U2 = in(:,:,u)';
            in(:,:,u) = U2;
        end

    end
end


Iter = 250;%iteration
Err = 2^-6;
in2 = Avg;

k2 = 30;

%%%%%%%%%% make sure diag(X)=0%%%%%%%%
for i = 1:1:size(in,3)
    Z = in(:,:,i);
    Z(logical(speye(size(Z)))) = 0;
    in(:,:,i) = Z;  
    Z2 = in2(:,:,i);
    Z2(logical(speye(size(Z2)))) = 0;
    in2(:,:,i) = Z2;
    
end
%%%%%%%% P is the weight matrix of initialization %%%%%%%%
P = ones(size(in,1),size(in,1));
P(logical(speye(size(P)))) = 0;
%%%%%%%% P1 is the weight matrix of prediction %%%%%%%%
if nargin > 7
        it = inT(:,:,pre-T:pre-1);% the used data of travel duration
        for i1 = 1:T
            dur = it(:,:,i1) - (T-i1)*900;
            dur(dur<=0) = 1;
            dur(dur~=1) = 0;
            P1(:,:,i1) = dur;
        end

         for i2 = 1:T
             PP = P1(:,:,i2);
             PP(logical(speye(size(PP)))) = 0;
             P1(:,:,i2) = PP;
         end
else
    P1 =P;
end
 
 V = in(:,:,pre-T:pre-1);




n = size(V(:,:,1),1);

Aa = 10+rand(k, k);
Bb = 10+rand(n, n);

[Whh,Hhh] = nmf(in2(:,:,pre),k,50);



for i = 1:T+1
    
   AA(:,:,i)=Aa;
    BB(:,:,i)=Bb;
end

for i = 1:T+1

    WW(:,:,i) = Whh;

    HH(:,:,i)= Hhh;
end

Vh = in2(:,:,pre-T:pre);
%%%%%%%% initialize Wt,Ht,At and Bt, get the history value of Wt+1,Ht+1%%%%%%%%
for i = 1:250

        for t = 1:T+1
        WWt = WW(:,:,t);
        HHt = HH(:,:,t);
        VVt = Vh(:,:,t);
        AAt = AA(:,:,t);
        BBt = BB(:,:,t); 
            if t == 1
            
          
            
            WWtE = WWt.*((P.*VVt*HHt'+la1.*(WWt*AAt+WW(:,:,t+1)*AAt'))./(P.*(WWt*HHt)*HHt'+la1.*(WWt+(WWt*AAt)*AAt')+eps));
            

            
                WWt = k2.*WWtE./norm(WWtE,'fro');

            
            HHt = HHt.*((WWt'*(P.*VVt)+la1.*(HHt*BBt+HH(:,:,t+1)*BBt'))./(WWt'*(P.*(WWt*HHt))+la1.*(HHt+(HHt*BBt)*BBt')+eps));
            
            
            
            AAt = AAt.*(la1.*WWt'*WW(:,:,t+1))./(la1.*WWt'*(WWt*AAt)+eps);                
            BBt = BBt.*(la1.*HHt'*HHt)./(la1.*HHt'*(HHt*BBt)+eps);
            
            
            
            WW(:,:,t) = WWt;
            HH(:,:,t) = HHt;
            AA(:,:,t) = AAt;
            BB(:,:,t) = BBt;  
        
            elseif t == T+1
              
            
            WWtE = WWt.*(P.*VVt*HHt'+la1.*(WW(:,:,t-1)*AA(:,:,t-1)+WWt*AAt'))./((P.*(WWt*HHt))*HHt'+la1.*(WWt+(WWt*AAt)*AAt')+eps);
            

            
                WWt = k2.*WWtE./norm(WWtE,'fro');

            
            HHt = HHt.*(WWt'*(P.*VVt)+la1.*(HH(:,:,t-1)*BB(:,:,t-1)+HHt*BBt'))./(WWt'*(P.*(WWt*HHt))+la1.*(HHt+(HHt*BBt)*BBt')+eps);
            
            
            
            
            AAt = AAt.*(la1.*WWt'*WWt)./(la1.*WWt'*(WWt*AAt)+eps);                        
            BBt = BBt.*(la1.*HHt'*HHt)./(la1.*HHt'*(HHt*BBt)+eps);
            
            
            
            AA(:,:,t) = AAt;
            BB(:,:,t) = BBt;

            WW(:,:,t) = WWt;
            HH(:,:,t) = HHt;
            
            else

            
            WWtE = WWt.*((P.*VVt*HHt'+la1.*(WW(:,:,t-1)*AA(:,:,t-1)+WW(:,:,t+1)*AAt'))./(P.*(WWt*HHt)*HHt'+la1.*(WWt+(WWt*AAt)*AAt')+eps));

            
                WWt = k2.*WWtE./norm(WWtE,'fro');

            
            HHt = HHt.*(WWt'*(P.*VVt)+la1.*(HH(:,:,t-1)*BB(:,:,t-1)+HH(:,:,t+1)*BBt'))./(WWt'*(P.*(WWt*HHt))+la1.*(HHt+(HHt*BBt)*BBt')+eps);                                
            
            
            
            AAt = AAt.*(la1.*WWt'*WW(:,:,t+1))./(la1.*WWt'*(WWt*AAt)+eps);                
            BBt = BBt.*(la1.*HHt'*HH(:,:,t+1))./(la1.*HHt'*(HHt*BBt)+eps);

            AA(:,:,t) = AAt;
            BB(:,:,t) = BBt;
            
            WW(:,:,t) = WWt;
            HH(:,:,t) = HHt;
            end       
        end

end


Wh1 = WWt;
Hh1 = HHt;
for i = 1:T
    A(:,:,i) = AAt;

    B(:,:,i)= BBt;
end  
for i = 1:T
    W(:,:,i) = Wh1;

    H(:,:,i)= Hh1;
end    
    L2 = getLoss2(W,H,Wh1,Hh1,V,P1,A,B,T,la1,la2);
    
%%%%%%%%%%%% prediction %%%%%%%%%%%%%%
for i = 1:Iter
    for t = 1:T
        Wt = W(:,:,t);
        Ht = H(:,:,t);
%         Wh1 = WW(:,:,t+1);
%         Hh1 = HH(:,:,t+1);
        At = A(:,:,t);
        Bt = B(:,:,t);
        Vt = V(:,:,t);
        if nargin > 7 
            Pt = P1(:,:,t);
        else
            Pt = P;
        end
        if t == 1
           
            WtE = Wt.*((Pt.*Vt*Ht'+la1.*(Wt*At+W(:,:,t+1)*At'))./(Pt.*(Wt*Ht)*Ht'+la1.*(Wt+(Wt*At)*At')+eps));
            

            
                Wt = k2.*WtE./norm(WtE,'fro');

            
            Ht = Ht.*((Wt'*(Pt.*Vt)+la1.*(Ht*Bt+H(:,:,t+1)*Bt'))./(Wt'*(Pt.*(Wt*Ht))+la1.*(Ht+(Ht*Bt)*Bt')+eps));              
            
            
            
            At = At.*(la1.*Wt'*W(:,:,t+1))./(la1.*Wt'*(Wt*At)+eps);                        
            Bt = Bt.*(la1.*Ht'*H(:,:,t+1))./(la1.*Ht'*(Ht*Bt)+eps);
            
            A(:,:,t) = At;
            B(:,:,t) = Bt;            
            W(:,:,t) = Wt;
            H(:,:,t) = Ht;
        
        elseif t == T
           
            WtE = Wt.*((Pt.*Vt*Ht'+la1.*(W(:,:,t-1)*A(:,:,t-1)+Wt*At')+la2.*Wh1*At')./((Pt.*(Wt*Ht))*Ht'+la1.*(Wt+(Wt*At)*At')+la2.*(Wt*At)*At'+eps));
            

            
                Wt = k2.*WtE./norm(WtE,'fro');

            
            Ht = Ht.*((Wt'*(Pt.*Vt)+la1.*(H(:,:,t-1)*B(:,:,t-1)+Ht*Bt')+la2.*Hh1*Bt')./(Wt'*(Pt.*(Wt*Ht))+la1.*(Ht+(Ht*Bt)*Bt')+la2.*(Ht*Bt)*Bt'+eps));
           
            
            
            At = At.*(la1.*Wt'*Wt+la2.*(Wt'*Wh1))./(la1.*Wt'*(Wt*At)+la2.*(Wt'*(Wt*At))+eps);                        
            Bt = Bt.*(la1.*Ht'*Ht+la2.*(Ht'*Hh1))./(la1.*Ht'*(Ht*Bt)+la2.*(Ht'*(Ht*Bt))+eps);
        
            A(:,:,t) = At;
            B(:,:,t) = Bt;
            W(:,:,t) = Wt;
            H(:,:,t) = Ht;
        
        else
            
            WtE = Wt.*((Pt.*Vt*Ht'+la1.*(W(:,:,t-1)*A(:,:,t-1)+W(:,:,t+1)*At'))./(Pt.*(Wt*Ht)*Ht'+la1.*(Wt+(Wt*At)*At')+eps));
            

            
                Wt = k2.*WtE./norm(WtE,'fro');

            
            Ht = Ht.*(Wt'*(Pt.*Vt)+la1.*(H(:,:,t-1)*B(:,:,t-1)+H(:,:,t+1)*Bt'))./(Wt'*(Pt.*(Wt*Ht))+la1.*(Ht+(Ht*Bt)*Bt')+eps);                                            
            
            
            
            At = At.*(la1.*Wt'*W(:,:,t+1))./(la1.*Wt'*(Wt*At)+eps);                
            Bt = Bt.*(la1.*Ht'*H(:,:,t+1))./(la1.*Ht'*(Ht*Bt)+eps);

            A(:,:,t) = At;
            B(:,:,t) = Bt;
            
            W(:,:,t) = Wt;
            H(:,:,t) = Ht;
        end
   
    end
    
    
    
    L1 = getLoss2(W,H,Wh1,Hh1,V,P1,A,B,T,la1,la2);
    L=L2-L1;
    L2 = L1;
    Q(i) = L1;
   if i>5
    if L<Err || L2>L1
        break;
    end
   end
    L2 = L1;
  
end
plot(Q);
gt_ba = Wt*At*(Ht*Bt);
if pre>64
    gt_ba = gt_ba';
end


end










