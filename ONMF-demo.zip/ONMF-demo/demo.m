
load('IN_Test.mat');
load('IN_TIME_STD.mat');
load('AvgIn.mat');


inT = IN_TIME_STD;
Avg = AvgIn;
input = IN_Test;

la1 = 2^6;
la2 = 2^13;
eta1 = 2^1.5;
eta2 = 2^5;
timestamp = 7;
WindowT1 = 6;
WindowT2 = 3;
k = 70; % latent dimension

[P1,gt] = ONMFAO(timestamp,WindowT1,k,la1,la2,Avg,input,inT);
P2 = ONMFMR(timestamp,WindowT2,k,eta1,eta2,Avg,input,inT);